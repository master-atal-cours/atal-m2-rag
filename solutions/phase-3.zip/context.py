"""Context : choisit et ordonne les passages montrés au LLM.

TP3 — ajouter les voisins utiles des meilleurs passages, dédoublonner, remettre
dans l'ordre des documents, respecter un budget de caractères.
"""

from __future__ import annotations

from .src.core import Hit, Index

NEIGHBOURS = 1  # voisins ajoutés de chaque côté d'un passage retrouvé…
EXPAND_TOP = 2  # … pour les EXPAND_TOP meilleurs passages seulement
MAX_CONTEXT_CHARS = 8_000  # budget de caractères pour les sources


class ContextBuilder:
    def __init__(self, index: Index):
        self.index = index

    def build(self, hits: list[Hit]) -> list[Hit]:
        """Élargit et ordonne les passages retrouvés.

        TP3 :
        1. pour les EXPAND_TOP meilleurs passages, ajouter leurs NEIGHBOURS voisins de
           chaque côté (``self.index.position[chunk.id]`` donne l'indice d'un passage dans
           ``self.index.chunks``) ; un voisin n'est utile que s'il prolonge la même section
           du même document (``chunk.doc_id`` et ``chunk.meta["section"]`` identiques) ;
        2. supprimer les doublons ;
        3. ordonner : documents par meilleur score décroissant, puis passages dans
           l'ordre du document ;
        4. s'arrêter avant de dépasser MAX_CONTEXT_CHARS.
        """
        chunks = self.index.chunks
        selected: dict[int, float] = {}
        for rank, hit in enumerate(hits):
            i = self.index.position[hit.chunk.id]
            selected[i] = max(selected.get(i, 0.0), hit.score)
            if rank >= EXPAND_TOP:
                continue
            for j in range(i - NEIGHBOURS, i + NEIGHBOURS + 1):
                if j == i or not 0 <= j < len(chunks):
                    continue
                neighbour = chunks[j]
                if neighbour.doc_id == hit.chunk.doc_id and neighbour.meta.get("section") == hit.chunk.meta.get("section"):
                    selected.setdefault(j, 0.0)
        best_of_doc: dict[str, float] = {}
        for j, score in selected.items():
            best_of_doc[chunks[j].doc_id] = max(best_of_doc.get(chunks[j].doc_id, 0.0), score)
        order = sorted(selected, key=lambda j: (-best_of_doc[chunks[j].doc_id], chunks[j].doc_id, j))
        context, size = [], 0
        for j in order:
            if context and size + len(chunks[j].text) > MAX_CONTEXT_CHARS:
                continue
            context.append(Hit(chunks[j], selected[j]))
            size += len(chunks[j].text)
        return context
