"""Encoder : transforme des textes en vecteurs (embeddings).

TP1 — appeler le modèle d'embeddings et normaliser les vecteurs.

``self.client.embed(textes)`` renvoie les vecteurs bruts, un par texte (tableau n × d),
calculés par le serveur et mis en cache.
"""

from __future__ import annotations

import numpy as np

from .src.embeddings import EmbeddingClient


class Encoder:
    def __init__(self, client: EmbeddingClient):
        self.client = client

    def encode_passages(self, texts: list[str]) -> np.ndarray:
        """Vecteurs des passages : tableau (n, d), une ligne par texte.

        TP1 : normaliser chaque ligne (norme L2 = 1, ``np.linalg.norm``) : le produit
        scalaire de deux vecteurs est alors leur similarité cosinus.
        """
        vectors = self.client.embed(texts)
        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        return vectors / np.maximum(norms, 1e-12)

    def encode_query(self, text: str) -> np.ndarray:
        """Vecteur d'une requête : tableau (d,), normalisé comme les passages."""
        return self.encode_passages([text])[0]
