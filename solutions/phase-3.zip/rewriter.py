"""Rewriter : transforme le dernier message en requête de recherche autonome.

TP3 — dans une conversation, le dernier message n'est pas autonome (« Et en 2020 ? »,
« Qui l'a fondée ? »). Le LLM le réécrit à partir de l'historique.
"""

from __future__ import annotations

from .src.core import Message
from .src.llm import LLM

REWRITE_PROMPT = """Tu reformules la dernière question d'une conversation en une requête de recherche courte et autonome (une phrase de moins de 25 mots), compréhensible sans l'historique.
Remplace les pronoms et les ellipses (« elle », « et en 2020 ? ») par ce qu'ils désignent, et conserve les noms propres, numéros, dates et noms de documents.
La requête exprime ce que demande la dernière question : n'y recopie pas le contenu des réponses précédentes.
Ne réponds pas à la question. Renvoie uniquement la requête."""


class QueryRewriter:
    def __init__(self, llm: LLM):
        self.llm = llm

    def rewrite(self, conversation: list[Message]) -> str:
        """Requête de recherche pour le dernier message.

        TP3 : sans historique (un seul message), renvoyer la question telle quelle.
        Sinon, demander au LLM (``self.llm.chat``) de la réécrire avec REWRITE_PROMPT,
        en lui donnant les derniers échanges et la dernière question.
        """
        question = conversation[-1]["content"]
        if len(conversation) == 1:
            return question
        names = {"user": "Utilisateur", "assistant": "Assistant"}
        history = "\n".join(
            f"{names.get(m['role'], m['role'])} : {m['content'][:600]}" for m in conversation[-7:-1]
        )
        rewritten = self.llm.chat(
            [
                {"role": "system", "content": REWRITE_PROMPT},
                {"role": "user", "content": f"Conversation :\n{history}\n\nDernière question : {question}"},
            ],
            max_tokens=120,
        )
        rewritten = rewritten.strip().strip('"«» ').splitlines()[0] if rewritten.strip() else ""
        return rewritten or question
