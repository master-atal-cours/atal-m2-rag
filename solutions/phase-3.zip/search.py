"""Search : retrouve les passages les plus pertinents pour une requête.

TP1 — recherche dense : similarité cosinus entre la requête et chaque passage.
TP2 — recherche hybride : dense + BM25 (mots exacts), fusionnées par Reciprocal
      Rank Fusion : score(d) = Σ 1 / (RRF_K + rang(d)).

Pour tester : onglet « Index » de l'interface, champ « Recherche ».
"""

from __future__ import annotations

import numpy as np
from rank_bm25 import BM25Okapi

from .encoder import Encoder
from .src.core import Hit, Index
from .src.text import tokenize

CANDIDATES = 50  # TP2 : nombre de résultats pris dans chaque classement avant la fusion
RRF_K = 60  # TP2 : constante de la Reciprocal Rank Fusion


class Search:
    def __init__(self, index: Index, encoder: Encoder):
        self.index = index
        self.encoder = encoder
        self.bm25 = BM25Okapi([tokenize(chunk.text) for chunk in index.chunks]) if index.chunks else None

    def find(self, query: str, k: int) -> list[Hit]:
        """Renvoie les k meilleurs passages, du plus au moins pertinent.

        TP1 : ``self.encoder.encode_query(query)`` donne le vecteur de la requête,
        ``self.index.vectors`` la matrice (n, d) des passages et ``self.index.chunks[i]``
        le passage n° i. Score = produit scalaire ; pensez à ``np.argsort``.
        Renvoyez des ``Hit(chunk, score, {"dense": score})``.

        TP2 : prendre les CANDIDATES meilleurs en dense et en BM25
        (``self.bm25.get_scores(tokenize(query))``), sommer 1 / (RRF_K + rang) sur les deux
        classements (rang à partir de 1), garder les k meilleurs. Les deux scores bruts
        vont dans ``Hit.details`` : {"dense": ..., "bm25": ...}.
        """
        if not self.index.chunks:
            return []
        dense = self.index.vectors @ self.encoder.encode_query(query)
        lexical = self.bm25.get_scores(tokenize(query))
        fused: dict[int, float] = {}
        for scores in (dense, lexical):
            for rank, i in enumerate(np.argsort(-scores)[:CANDIDATES], start=1):
                fused[int(i)] = fused.get(int(i), 0.0) + 1 / (RRF_K + rank)
        best = sorted(fused, key=fused.get, reverse=True)[:k]
        return [
            Hit(self.index.chunks[i], fused[i], {"dense": float(dense[i]), "bm25": float(lexical[i])})
            for i in best
        ]
