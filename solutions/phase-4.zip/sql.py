"""SQL : répond aux questions de calcul sur les tableaux du corpus (text-to-SQL).

TP4 — une agrégation (« combien de contrôles en 2025 ? ») porte sur des centaines de
lignes : aucun ensemble de passages ne les contient toutes. Le LLM écrit une requête
SQL, exécutée en lecture seule sur une base construite à partir des tableaux du corpus.
"""

from __future__ import annotations

from .src.core import Answer, Message
from .src.llm import LLM
from .src.tables import SQLError, TableStore, format_result

SQL_PROMPT = """Tu écris une requête SQL (dialecte SQLite) qui répond à la question de l'utilisateur, à partir des tables ci-dessous.
- Utilise uniquement ces tables et ces colonnes, avec leur nom exact.
- Pour comparer du texte, utilise LIKE '%...%' avec les valeurs possibles indiquées.
- Une seule requête SELECT. Réponds uniquement avec la requête, sans explication.

Tables :
{schema}"""

DATA_ANSWER_PROMPT = """Tu es un chatbot de questions-réponses sur la réglementation de l'IA en France. Réponds à la question de l'utilisateur à partir du résultat de la requête SQL ci-dessous, exécutée sur les données suivantes : {sources}.
Réponds en une ou deux phrases, en français, en citant la source des données. Si ces données ne couvrent pas la période ou le périmètre demandés, dis-le au lieu de répondre.

Requête : {sql}
Résultat :
{result}"""


class SQLTool:
    def __init__(self, llm: LLM, tables: TableStore):
        self.llm = llm
        self.tables = tables

    def answer(self, conversation: list[Message], question: str) -> Answer | None:
        """Répond à ``question`` (déjà réécrite en requête autonome) par une requête SQL.

        Renvoie None si aucune requête valide n'a pu être écrite : le pipeline se rabat
        alors sur la recherche documentaire.

        TP4 :
        1. tables pertinentes : ``self.tables.search(question, k=3)`` (des noms), et leur
           description : ``self.tables.schema(noms)`` ;
        2. le LLM écrit la requête (``self.llm.chat``, avec SQL_PROMPT) ;
        3. exécution : ``self.tables.query(sql)`` renvoie (colonnes, lignes) ou lève SQLError ;
           en cas d'erreur, ou si le résultat est vide ou nul (souvent un filtre erroné),
           redonner le problème au LLM une fois ;
        4. le LLM formule la réponse à partir du résultat (DATA_ANSWER_PROMPT,
           ``format_result(colonnes, lignes)``).
        Mettez la requête dans la trace (``"sql"``) et les documents des tables utilisées
        dans ``"documents"`` (``table.doc_id`` pour ``table`` dans ``self.tables.tables``).
        """
        names = self.tables.search(question, k=3)
        tables = [t for t in self.tables.tables if t.name in names]
        messages = [
            {"role": "system", "content": SQL_PROMPT.format(schema=self.tables.schema(names))},
            {"role": "user", "content": question},
        ]
        sql, result = "", None
        for attempt in range(2):
            sql = self.llm.chat(messages, max_tokens=400)
            try:
                columns, rows = self.tables.query(sql)
                # Un résultat vide, nul ou à zéro trahit souvent un filtre erroné
                # (« santé » au lieu de « Santé ») : on le fait vérifier une fois.
                if attempt == 0 and all(v in (None, 0) for row in rows for v in row):
                    raise SQLError("résultat vide ou nul : vérifie les filtres (valeurs possibles dans le schéma)")
                result = format_result(columns, rows)
                break
            except SQLError as e:
                messages += [
                    {"role": "assistant", "content": sql},
                    {"role": "user", "content": f"Cette requête échoue : {e}. Corrige-la."},
                ]
        if result is None:
            return None
        sources = "; ".join(f"{t.name} ({t.title})" for t in tables)
        system = DATA_ANSWER_PROMPT.format(sources=sources, sql=sql, result=result)
        return Answer(
            stream=self.llm.stream([{"role": "system", "content": system}, {"role": "user", "content": question}]),
            trace={"sql": sql, "result": result[:500], "documents": sorted({t.doc_id for t in tables})},
        )
